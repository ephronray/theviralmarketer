<?php 

$route['test'] = 'test';