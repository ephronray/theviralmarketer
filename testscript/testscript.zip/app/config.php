<?php
//Config Database
define('DB_HOST', 'localhost');
define('DB_USER', 'ephronon_twitter');
define('DB_PASS', 'zT(qiU1V*ZRE');
define('DB_NAME', 'ephronon_test_twitter_script');
define('TIMEZONE', 'Africa/Abidjan');
define('ENCRYPTION_KEY', 'ec21b9da9b3194a32eb44723ee1ea569');