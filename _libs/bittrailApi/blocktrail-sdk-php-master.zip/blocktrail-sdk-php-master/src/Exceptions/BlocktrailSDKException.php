<?php

namespace Blocktrail\SDK\Exceptions;

class BlocktrailSDKException extends \Exception {

}
