<?php

namespace Blocktrail\SDK\Connection\Exceptions;

use Blocktrail\SDK\Exceptions\BlocktrailSDKException;

/**
 * Class GenericServerError
 *
 */
class GenericServerError extends BlocktrailSDKException {

}
