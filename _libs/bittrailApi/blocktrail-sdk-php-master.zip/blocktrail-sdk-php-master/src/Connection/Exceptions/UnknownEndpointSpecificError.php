<?php

namespace Blocktrail\SDK\Connection\Exceptions;

use Blocktrail\SDK\Exceptions\BlocktrailSDKException;

/**
 * Class UnknownEndpointSpecificError
 *
 */
class UnknownEndpointSpecificError extends BlocktrailSDKException {

}
